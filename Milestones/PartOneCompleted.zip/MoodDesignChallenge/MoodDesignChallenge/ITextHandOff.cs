﻿namespace MoodDesignChallenge
{
    public interface ITextHandOff
    {
        void Handoff(string text);
    }
}