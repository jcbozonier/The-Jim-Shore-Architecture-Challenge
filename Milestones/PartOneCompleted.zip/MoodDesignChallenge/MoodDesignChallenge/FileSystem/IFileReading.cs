﻿namespace MoodDesignChallenge.FileSystem
{
    public interface IFileReading
    {
        void Read();
    }
}